﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;


namespace hastaneC
{
    public class Mysqlbaglantisi
    {

        public MySqlConnection baglanti()
        {
            MySqlConnection baglan = new MySqlConnection("Server=localhost;Database=hastanedb;Uid=root;Pwd=");
            baglan.Open();
            return baglan;
        }


        private void Formgirisler_Load(object sender, EventArgs e)
        {
           
        }
    }
}

